-- Base de données SAÉ3.02
-- Structure complete avec donnees de test

USE sae302;

-- Table des privileges
CREATE TABLE IF NOT EXISTS privileges (
    id INT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

INSERT INTO privileges (id, nom) VALUES 
(1, 'consultation des journaux'),
(2, 'gestion des serveurs'),
(4, 'administration des utilisateurs');

-- Table des roles
CREATE TABLE IF NOT EXISTS roles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(50) NOT NULL,
    privileges INT NOT NULL
) ENGINE=InnoDB;

INSERT INTO roles (id, nom, privileges) VALUES 
(1, 'utilisateur', 1),
(2, 'gestionnaire', 3),
(3, 'administrateur', 7);

-- Table des utilisateurs
CREATE TABLE IF NOT EXISTS utilisateurs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(100) NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL,
    role_id INT NOT NULL,
    FOREIGN KEY (role_id) REFERENCES roles(id)
) ENGINE=InnoDB;

-- Utilisateur admin par defaut
-- Mot de passe : admin123
-- Hash SHA-256 : 240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9
INSERT INTO utilisateurs (nom, mot_de_passe, role_id) VALUES 
('admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 3);

-- Table des machines
CREATE TABLE IF NOT EXISTS machines (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(100) NOT NULL UNIQUE,
    adresse_ip VARCHAR(15) NOT NULL
) ENGINE=InnoDB;

-- Machines de demonstration
INSERT INTO machines (nom, adresse_ip) VALUES 
('Serveur-Local', '127.0.0.1'),
('Hote1-SAE302', '192.168.122.101'),
('Hote2-SAE302', '192.168.122.104');
