from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
import hashlib
import paramiko
import re

# configuration
app = Flask(__name__)
app.secret_key = 'qamu'

# config mysql directement repris du tp3
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://sae302:qamu@localhost/sae302'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Identifiants SSH pour les connexions aux serveurs
SSH_USER = 'qamu'
SSH_PASSWORD = 'qamu'

# Tables de la base de donnee
class Privilege(db.Model):
    __tablename__ = 'privileges'
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(100), nullable=False)

class Role(db.Model):
    __tablename__ = 'roles'
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(50), nullable=False)
    privileges = db.Column(db.Integer, nullable=False)

class Utilisateur(db.Model):
    __tablename__ = 'utilisateurs'
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(100), nullable=False, unique=True)
    mot_de_passe = db.Column(db.String(255), nullable=False)
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id'), nullable=False)
    # Relation avec le role
    role = db.relationship('Role', backref='utilisateurs')

class Machine(db.Model):
    __tablename__ = 'machines'
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(100), nullable=False, unique=True)
    adresse_ip = db.Column(db.String(15), nullable=False)

# Fonction de python pour le hash du password
def hash_password(password):
    """Hache le mot de passe avec SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def a_privilege(privilege_requis):
    """Verifie si l'utilisateur a le privilège requis (opération bit à bit)"""
    if 'privileges' in session:
        privileges_user = session['privileges']
        # bit à bit
        if (privileges_user & privilege_requis) == privilege_requis:
            return True
    return False

def ip_valide(ip):
    """Valide le format d'une adresse IP"""
    pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
    if re.match(pattern, ip):
        parties = ip.split('.')
        for partie in parties:
            if int(partie) > 255:
                return False
        return True
    return False

def recuperer_logs(ip, nb_lignes=100):
    """Recupere les logs syslog d'un serveur"""
    # Si serveur local, lecture directe
    if ip == '192.168.122.100':
        try:
            with open('/var/log/syslog', 'r') as f:
                lignes = f.readlines()
                return ''.join(lignes[-nb_lignes:])
        except:
            return "Erreur lecture fichier local"
    
    # Sinon connexion SSH
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(ip, username=SSH_USER, password=SSH_PASSWORD, timeout=10)
        
        stdin, stdout, stderr = client.exec_command('tail -n ' + str(nb_lignes) + ' /var/log/syslog')
        resultat = stdout.read().decode('utf-8')
        client.close()
        return resultat
    except Exception as e:
        return "Erreur SSH: " + str(e)

def parser_ligne_log(ligne):
    """Parse une ligne de syslog"""
    parties = ligne.split(None, 4)
    if len(parties) >= 5:
        return {
            'date': parties[0] + ' ' + parties[1] + ' ' + parties[2],
            'hote': parties[3],
            'message': parties[4]
        }
    else:
        return {'date': '', 'hote': '', 'message': ligne}

#Les routes
@app.route('/')
def index():
    """Page d'accueil"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Calcul des privileges pour le menu
    privileges = {
        'journaux': a_privilege(1),
        'serveurs': a_privilege(2),
        'utilisateurs': a_privilege(4)
    }
    
    return render_template('index.html', privileges=privileges)

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Page de connexion"""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Hash du mot de passe saisi
        password_hash = hash_password(password)
        
        # Recherche de l'utilisateur
        user = Utilisateur.query.filter_by(nom=username).first()
        
        if user and user.mot_de_passe == password_hash:
            # Connexion reussie
            session['user_id'] = user.id
            session['username'] = user.nom
            session['privileges'] = user.role.privileges
            flash('Connexion réussie !', 'success')
            return redirect(url_for('index'))
        else:
            flash('Identifiant ou mot de passe incorrect', 'error')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    """Deconnexion"""
    session.clear()
    flash('Vous etes deconnecte', 'info')
    return redirect(url_for('login'))

@app.route('/journaux', methods=['GET', 'POST'])
def journaux():
    """Page de consultation des journaux"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if not a_privilege(1):
        flash('Acces refuse', 'error')
        return redirect(url_for('index'))
    
    # Liste des machines
    machines = Machine.query.order_by(Machine.nom).all()
    
    logs = []
    machines_selectionnees = []
    
    if request.method == 'POST':
        machines_selectionnees = request.form.getlist('machines')
        
        # Pour chaque machine selectionnee
        for machine_id in machines_selectionnees:
            machine = Machine.query.get(machine_id)
            
            if machine:
                # Recuperation des logs
                logs_bruts = recuperer_logs(machine.adresse_ip)
                lignes = logs_bruts.split('\n')
                
                # Parsing
                for ligne in lignes:
                    if ligne.strip():
                        log_parse = parser_ligne_log(ligne)
                        log_parse['serveur'] = machine.nom
                        logs.append(log_parse)
        
        # Tri decroissant
        logs.reverse()
    
    # Calcul des privileges pour le menu
    privileges = {
        'journaux': a_privilege(1),
        'serveurs': a_privilege(2),
        'utilisateurs': a_privilege(4)
    }
    
    return render_template('journaux.html', machines=machines, logs=logs, 
                         selected=machines_selectionnees, privileges=privileges)

@app.route('/serveurs', methods=['GET', 'POST'])
def serveurs():
    """Page de gestion des serveurs"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if not a_privilege(2):
        flash('Accès refusé : vous devez être gestionnaire', 'error')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        action = request.form['action']
        
        # Ajout
        if action == 'ajouter':
            nom = request.form['nom']
            ip = request.form['ip']
            
            if not ip_valide(ip):
                flash('Adresse IP invalide', 'error')
            else:
                try:
                    nouvelle_machine = Machine(nom=nom, adresse_ip=ip)
                    db.session.add(nouvelle_machine)
                    db.session.commit()
                    flash('Machine ajoutée avec succès', 'success')
                except:
                    db.session.rollback()
                    flash("Erreur lors de l'ajout", 'error')
        
        # Suppression
        elif action == 'supprimer':
            machine_id = request.form['machine_id']
            machine = Machine.query.get(machine_id)
            if machine:
                db.session.delete(machine)
                db.session.commit()
                flash('Machine supprimée', 'success')
    
    # Liste des machines
    machines = Machine.query.order_by(Machine.nom).all()
    
    # Privileges pour le menu
    privileges = {
        'journaux': a_privilege(1),
        'serveurs': a_privilege(2),
        'utilisateurs': a_privilege(4)
    }
    
    return render_template('serveurs.html', machines=machines, privileges=privileges)

@app.route('/serveurs/modifier/<int:machine_id>', methods=['GET', 'POST'])
def modifier_serveur(machine_id):
    """Modification d'un serveur"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if not a_privilege(2):
        flash('Accès refusé', 'error')
        return redirect(url_for('index'))
    
    machine = Machine.query.get(machine_id)
    
    if not machine:
        flash('Machine introuvable', 'error')
        return redirect(url_for('serveurs'))
    
    if request.method == 'POST':
        nouvelle_ip = request.form['ip']
        
        if not ip_valide(nouvelle_ip):
            flash('Adresse IP invalide', 'error')
        else:
            machine.adresse_ip = nouvelle_ip
            db.session.commit()
            flash('Machine modifiée avec succès', 'success')
            return redirect(url_for('serveurs'))
    
    # Privileges pour le menu
    privileges = {
        'journaux': a_privilege(1),
        'serveurs': a_privilege(2),
        'utilisateurs': a_privilege(4)
    }
    
    return render_template('modifier_serveur.html', machine=machine, privileges=privileges)

@app.route('/utilisateurs', methods=['GET', 'POST'])
def utilisateurs():
    """Page de gestion des utilisateurs"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if not a_privilege(4):
        flash('Accès refusé : vous devez être administrateur', 'error')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        action = request.form['action']
        
        # Ajout
        if action == 'ajouter':
            nom = request.form['nom']
            password = request.form['password']
            role_id = request.form['role_id']
            
            password_hash = hash_password(password)
            
            try:
                nouvel_user = Utilisateur(nom=nom, mot_de_passe=password_hash, role_id=role_id)
                db.session.add(nouvel_user)
                db.session.commit()
                flash('Utilisateur ajouté avec succès', 'success')
            except:
                db.session.rollback()
                flash("Erreur lors de l'ajout", 'error')
        
        # Suppression
        elif action == 'supprimer':
            user_id = request.form['user_id']
            if int(user_id) == session['user_id']:
                flash('Vous ne pouvez pas supprimer votre propre compte', 'error')
            else:
                user = Utilisateur.query.get(user_id)
                if user:
                    db.session.delete(user)
                    db.session.commit()
                    flash('Utilisateur supprimé', 'success')
    
    # Liste des utilisateurs avec leurs roles
    users = Utilisateur.query.order_by(Utilisateur.nom).all()
    roles = Role.query.order_by(Role.id).all()
    
    # Privileges pour le menu
    privileges = {
        'journaux': a_privilege(1),
        'serveurs': a_privilege(2),
        'utilisateurs': a_privilege(4)
    }
    
    return render_template('utilisateurs.html', users=users, roles=roles, privileges=privileges)

@app.route('/utilisateurs/modifier/<int:user_id>', methods=['GET', 'POST'])
def modifier_utilisateur(user_id):
    user = Utilisateur.query.get(user_id)
    
    if request.method == 'POST':
        user.nom = request.form['nom']
        
        user.role_id = request.form['role'] 
        
        nouveau_mdp = request.form['mot_de_passe']
        if nouveau_mdp:
            user.mot_de_passe = hashlib.sha256(nouveau_mdp.encode()).hexdigest()
        
        try:
            db.session.commit()
            return redirect(url_for('utilisateurs'))
        except:
            db.session.rollback()
            return "Erreur lors de la modification"

    roles = Role.query.all()
    # On recupere les privilege pour le menu
    privileges = session.get('privileges', 0)
    
    return render_template('modifier_utilisateur.html', user=user, roles=roles, privileges=privileges)

    
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
