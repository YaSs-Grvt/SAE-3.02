#!/bin/bash

# Affichage du titre
echo "=== Installation de la SAE 3.02 ==="

# Mise à jour et installation des paquets
echo "1. Installation des logiciels..."
sudo apt update
# Installation de MariaDB et des outils Python
sudo apt install -y mariadb-server python3-venv python3-pip

# Configuration de la Base de Données
echo "2. Configuration de la BDD..."
# On s assure que le service mysql est demarre
sudo systemctl start mariadb

# J utilise le | pour envoyer les commandes sql directement sans ouvrir le prompt
# On utilise les identifiants 'sae302' / 'qamu' comme dans le code Python
echo "CREATE DATABASE IF NOT EXISTS sae302; CREATE USER IF NOT EXISTS 'sae302'@'localhost' IDENTIFIED BY 'qamu'; GRANT ALL PRIVILEGES ON sae302.* TO 'sae302'@'localhost'; FLUSH PRIVILEGES;" | sudo mysql


# importer les donnee sql
sudo mysql sae302 < database.sql

# Installation de Python
echo "3. Création de l'environnement virtuel..."
# Creation du dossier venv pour isoler les librairies
python3 -m venv venv

# Installation des dépendances avec pip (chemin relatif vers l'executable du venv)
./venv/bin/pip install flask flask-sqlalchemy mysql-connector-python paramiko

# Gestion des droits
echo "4. Ajout des droits de lecture des logs..."
# On ajoute l'utilisateur courant ($USER) au groupe adm pour lire /var/log/syslog
sudo usermod -aG adm $USER

echo "=== Installation terminée ==="
echo "Pour lancer le site :"
echo "source venv/bin/activate"
echo "python3 app.py"

# Retourne 0 pour dire que tout s'est bien passe
exit 0
